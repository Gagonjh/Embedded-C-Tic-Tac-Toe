var classc_dev_text_i_o =
[
    [ "getString", "classc_dev_text_i_o.html#a5010b44ac0c948065277c47d34b9a9fa", null ],
    [ "printf", "classc_dev_text_i_o.html#a69a46fabc43314ace6cc74520e76a220", null ]
];
var classc_list_1_1_item =
[
    [ "Item", "classc_list_1_1_item.html#ae2e30fb6348e5fa0debb9ba0d3d8d3b5", null ],
    [ "getNext", "classc_list_1_1_item.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_list_1_1_item.html#ab07463368796c2655c2ce536159ab69e", null ]
];
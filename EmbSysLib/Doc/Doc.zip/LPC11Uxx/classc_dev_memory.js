var classc_dev_memory =
[
    [ "cDevMemory", "classc_dev_memory.html#a311cbc02c732205e0319f18126c989ae", null ],
    [ "allocate", "classc_dev_memory.html#aa9a64b0c29d44487494928f81ed7a045", null ],
    [ "write", "classc_dev_memory.html#a8e1206a5175586c6af40cbbf9998938b", null ],
    [ "read", "classc_dev_memory.html#a19df127d88622bd9ff4cf5abf1ab049f", null ],
    [ "clear", "classc_dev_memory.html#aefedbf4075263ee2d2cfa85dee0b005e", null ],
    [ "setValid", "classc_dev_memory.html#a5efa387a7b395d5764c34cbcba4c38d0", null ],
    [ "isValid", "classc_dev_memory.html#abd7a70ac725b546b8bfbee0509e7e79b", null ]
];
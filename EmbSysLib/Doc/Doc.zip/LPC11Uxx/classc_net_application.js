var classc_net_application =
[
    [ "getNext", "classc_net_application.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_net_application.html#ab07463368796c2655c2ce536159ab69e", null ]
];
var classc_dev_control_pointer_1_1c_data =
[
    [ "Flags", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10", [
      [ "NONE", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10abafb12395afb110f83cb8f125a8a76f2", null ],
      [ "PRESSED", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10ae112796dd000cdfe59802ec3310c3cfa", null ],
      [ "MOVE_X", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10a6ba1680d1d1ad346fcb039fa08f31786", null ],
      [ "MOVE_Y", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10a2449ce158c6e03fb9948bf6893899a5e", null ],
      [ "CTRL_DWN", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10a9a9465ee6586b29c412ae79b6b083c60", null ],
      [ "CTRL_UP", "classc_dev_control_pointer_1_1c_data.html#a3bd73c2706335beb7c82b062a7950f10ae53c98414c5a0ed5bcc582f5fbc1fc32", null ]
    ] ],
    [ "posX", "classc_dev_control_pointer_1_1c_data.html#afd51e78416200fe4ef28d75b0f77dba7", null ],
    [ "posY", "classc_dev_control_pointer_1_1c_data.html#ad1477e2fdf4c2ed4b9e51792a69ac03f", null ],
    [ "delta", "classc_dev_control_pointer_1_1c_data.html#ad6fec41eaec6190916c4b37b24c7dc6d", null ],
    [ "flags", "classc_dev_control_pointer_1_1c_data.html#af9d77b2a33762228a8f5771e526b0692", null ]
];
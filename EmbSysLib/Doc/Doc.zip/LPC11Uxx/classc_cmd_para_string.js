var classc_cmd_para_string =
[
    [ "modeType", "classc_cmd_para_string.html#a9ce830464e14fecd6a7a0db6f2eaafa6", [
      [ "NORMAL", "classc_cmd_para_string.html#a9ce830464e14fecd6a7a0db6f2eaafa6a539c6c9fc9f7ed86c6d5b87b82a3745e", null ],
      [ "RDONLY", "classc_cmd_para_string.html#a9ce830464e14fecd6a7a0db6f2eaafa6acaabf6dcc2092a84c6f32a7e36aca9e8", null ],
      [ "MEMORY", "classc_cmd_para_string.html#a9ce830464e14fecd6a7a0db6f2eaafa6a12b77fea5755b18bb44af5c8b009bce3", null ],
      [ "EVENT", "classc_cmd_para_string.html#a9ce830464e14fecd6a7a0db6f2eaafa6ab870e4c688e44c9ea666f94a2647d340", null ]
    ] ],
    [ "cCmdParaString", "classc_cmd_para_string.html#a8890fb5d4b6f181dcabb6215e61e9c93", null ],
    [ "set", "classc_cmd_para_string.html#a5dc8de214b9575e7d5d5530c398e6603", null ],
    [ "get", "classc_cmd_para_string.html#a13aac66700239e9c6a06667fbe7c36ae", null ],
    [ "operator const char *", "classc_cmd_para_string.html#a342cb4e199fdd800379a408c3be99150", null ],
    [ "isNew", "classc_cmd_para_string.html#a95ad4cd84a91028d63579ed394b6cd14", null ]
];
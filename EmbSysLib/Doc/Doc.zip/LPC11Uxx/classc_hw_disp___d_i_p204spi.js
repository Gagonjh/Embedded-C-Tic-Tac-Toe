var classc_hw_disp___d_i_p204spi =
[
    [ "cHwDisp_DIP204spi", "classc_hw_disp___d_i_p204spi.html#a3b31be32440bd8ced9dc567bf8e7b1a1", null ],
    [ "clear", "classc_hw_disp___d_i_p204spi.html#a93334b932bd547df9c08df2b1e2d31e4", null ],
    [ "refresh", "classc_hw_disp___d_i_p204spi.html#a557d723232d577f75ec432fdf39fb9aa", null ],
    [ "gotoTextPos", "classc_hw_disp___d_i_p204spi.html#a80b4283341b6aac1d7b80523c46aaec7", null ],
    [ "putChar", "classc_hw_disp___d_i_p204spi.html#a5996eb637aafd26a30d6d0321de9192b", null ],
    [ "getNumberOfLines", "classc_hw_disp___d_i_p204spi.html#a3fd16575852744859c377efc8e14cc03", null ],
    [ "getNumberOfColumns", "classc_hw_disp___d_i_p204spi.html#a81064220d03de8b1cafa13089a0433e2", null ]
];
var classc_cmd =
[
    [ "cCmd", "classc_cmd.html#a7ff581709b79e8b60e08557d7a60b0ec", null ],
    [ "update", "classc_cmd.html#aa935187559854b64fae367a97cea11ef", null ],
    [ "isNew", "classc_cmd.html#a7787b6fd99b06a5f195fb77af2746c12", null ],
    [ "clear", "classc_cmd.html#a8ef8023bba1e40543ac8ac538edfa150", null ]
];
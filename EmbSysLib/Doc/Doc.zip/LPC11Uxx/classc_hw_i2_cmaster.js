var classc_hw_i2_cmaster =
[
    [ "Device", "classc_hw_i2_cmaster_1_1_device.html", "classc_hw_i2_cmaster_1_1_device" ],
    [ "MODE", "classc_hw_i2_cmaster.html#a44d89e5a296f3a96822d3a7903ec74a3", [
      [ "CR_10kHz", "classc_hw_i2_cmaster.html#a44d89e5a296f3a96822d3a7903ec74a3a8728d810ce65db04a837f625ed4392f8", null ],
      [ "CR_100kHz", "classc_hw_i2_cmaster.html#a44d89e5a296f3a96822d3a7903ec74a3a3cb42efb1c57d83a1e2609bddf146330", null ],
      [ "CR_400kHz", "classc_hw_i2_cmaster.html#a44d89e5a296f3a96822d3a7903ec74a3a56c3205fa502de775c84f69c5b773022", null ],
      [ "CR_1000kHz", "classc_hw_i2_cmaster.html#a44d89e5a296f3a96822d3a7903ec74a3a578d42c91b10a56cf12d85abe75db104", null ]
    ] ]
];
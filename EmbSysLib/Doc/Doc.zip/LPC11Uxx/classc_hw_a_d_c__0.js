var classc_hw_a_d_c__0 =
[
    [ "cHwADC_0", "classc_hw_a_d_c__0.html#a250a154511d5b6d48b498bcbc0dc7411", null ],
    [ "enable", "classc_hw_a_d_c__0.html#a644973d42e46799d8c3fd56d67b27fe1", null ],
    [ "get", "classc_hw_a_d_c__0.html#aa0e6dcab520652aa8a6636765515d95d", null ],
    [ "getNumberOfChannels", "classc_hw_a_d_c__0.html#a6dc1940a9192d6c429e7c854a5f9c7ff", null ],
    [ "update", "classc_hw_a_d_c__0.html#ad5e4e6da433c2b43c08f9bd9e131d962", null ],
    [ "getNext", "classc_hw_a_d_c__0.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_hw_a_d_c__0.html#ab07463368796c2655c2ce536159ab69e", null ]
];
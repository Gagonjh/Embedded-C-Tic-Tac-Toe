var classc_hw_disp___terminal =
[
    [ "cHwDisp_Terminal", "classc_hw_disp___terminal.html#a9975a97c18c8e6c16cdae23f21d8d7b4", null ],
    [ "clear", "classc_hw_disp___terminal.html#a8546c6498609c5b8007acc81f7981fa8", null ],
    [ "refresh", "classc_hw_disp___terminal.html#ae6f07fe936f6c80bc8d9770b1d03a6db", null ],
    [ "gotoTextPos", "classc_hw_disp___terminal.html#a395911120355297789b04ece696a729d", null ],
    [ "putChar", "classc_hw_disp___terminal.html#af995386c3d0cf075e02ff9b0a65f0178", null ],
    [ "getNumberOfLines", "classc_hw_disp___terminal.html#a3fd16575852744859c377efc8e14cc03", null ],
    [ "getNumberOfColumns", "classc_hw_disp___terminal.html#a81064220d03de8b1cafa13089a0433e2", null ]
];
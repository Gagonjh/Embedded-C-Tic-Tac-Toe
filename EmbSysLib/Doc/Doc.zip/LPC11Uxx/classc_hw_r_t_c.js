var classc_hw_r_t_c =
[
    [ "Properties", "classc_hw_r_t_c_1_1_properties.html", "classc_hw_r_t_c_1_1_properties" ],
    [ "set", "classc_hw_r_t_c.html#aef252f613a86423b01bc114a78d6b1ba", null ],
    [ "get", "classc_hw_r_t_c.html#a9f30dc89a35b32ba8366568789698fe6", null ]
];
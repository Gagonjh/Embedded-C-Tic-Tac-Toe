var classc_dev_analog_in_a_d_c =
[
    [ "cDevAnalogInADC", "classc_dev_analog_in_a_d_c.html#a478d06d2dd4598d56f8a47c06b65edcc", null ],
    [ "getRaw", "classc_dev_analog_in_a_d_c.html#aa7c0632e8bdfee0b93ce19f4eda84ac0", null ],
    [ "get", "classc_dev_analog_in_a_d_c.html#aea5f1cc2c05dc659341a7d72bc21258d", null ],
    [ "operator float", "classc_dev_analog_in_a_d_c.html#af8c804410dad4721dab032bfdb8eec6f", null ],
    [ "calibrate", "classc_dev_analog_in_a_d_c.html#a139e2287c343d2b5ed974c6a995f5ad8", null ]
];
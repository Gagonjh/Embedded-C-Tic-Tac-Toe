var classc_hw_r_t_c_1_1_properties =
[
    [ "year", "classc_hw_r_t_c_1_1_properties.html#a1a2acadefabec6ec29576512c9699fdd", null ],
    [ "month", "classc_hw_r_t_c_1_1_properties.html#a027ab86db690f7112e5885be0d2806c3", null ],
    [ "day", "classc_hw_r_t_c_1_1_properties.html#ae6f0d3fd8cb0308ed6678a9fafc896c4", null ],
    [ "dow", "classc_hw_r_t_c_1_1_properties.html#a2465ec82ef75ece508919a692618d30b", null ],
    [ "hour", "classc_hw_r_t_c_1_1_properties.html#a45efbcf907150681873e3c823ffcb364", null ],
    [ "minute", "classc_hw_r_t_c_1_1_properties.html#a3097d7a1e75a218b2483ae22cf861805", null ],
    [ "second", "classc_hw_r_t_c_1_1_properties.html#ab3128a07bcdbd1c957b07cbec2788664", null ]
];
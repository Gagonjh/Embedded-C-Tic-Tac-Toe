var classc_dev_control_encoder_rotary_knob =
[
    [ "tEvent", "classc_dev_control_encoder_rotary_knob.html#a3ab0fe57c243744b200d28171d0fc95b", [
      [ "NONE", "classc_dev_control_encoder_rotary_knob.html#a3ab0fe57c243744b200d28171d0fc95ba9eca818c7942da7d59db7f74cb6f254d", null ],
      [ "LEFT", "classc_dev_control_encoder_rotary_knob.html#a3ab0fe57c243744b200d28171d0fc95ba5f34d6027687d548fda3cca79f451449", null ],
      [ "RIGHT", "classc_dev_control_encoder_rotary_knob.html#a3ab0fe57c243744b200d28171d0fc95bafa3a28eb23e6a2e05a1ff0dbeb734638", null ],
      [ "CTRL_DWN", "classc_dev_control_encoder_rotary_knob.html#a3ab0fe57c243744b200d28171d0fc95ba7c32817c08aace7b310f26ca014307f9", null ],
      [ "CTRL_UP", "classc_dev_control_encoder_rotary_knob.html#a3ab0fe57c243744b200d28171d0fc95ba6963591c0188f5e28f1c35cd534ddc5b", null ]
    ] ],
    [ "cDevControlEncoderRotaryKnob", "classc_dev_control_encoder_rotary_knob.html#a0d1edccd36453d91ce752b4503981c9b", null ],
    [ "get", "classc_dev_control_encoder_rotary_knob.html#af6a4230694671750fbcf0ac60d221eb0", null ],
    [ "update", "classc_dev_control_encoder_rotary_knob.html#aaebb01cdc78d4d2075995980c7e2a6d4", null ],
    [ "getNext", "classc_dev_control_encoder_rotary_knob.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_dev_control_encoder_rotary_knob.html#ab07463368796c2655c2ce536159ab69e", null ]
];
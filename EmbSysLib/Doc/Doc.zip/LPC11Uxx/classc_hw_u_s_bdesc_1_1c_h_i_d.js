var classc_hw_u_s_bdesc_1_1c_h_i_d =
[
    [ "_HID_DESCRIPTOR_LIST", "structc_hw_u_s_bdesc_1_1c_h_i_d_1_1___h_i_d___d_e_s_c_r_i_p_t_o_r___l_i_s_t.html", null ],
    [ "DescriptorList", "classc_hw_u_s_bdesc_1_1c_h_i_d.html#a1310b8efc54edf27401eb5f8bd38adb0", null ]
];
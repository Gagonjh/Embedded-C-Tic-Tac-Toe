var classc_c_r_c =
[
    [ "MODE", "classc_c_r_c.html#a6f4a0c27cf764777e07bbb75349cf1ce", [
      [ "SMALL", "classc_c_r_c.html#a6f4a0c27cf764777e07bbb75349cf1cea5ec9347a4ff56db811bb109256875eea", null ],
      [ "FAST", "classc_c_r_c.html#a6f4a0c27cf764777e07bbb75349cf1cea410a563feb51b8135d09dc52d9627566", null ]
    ] ],
    [ "cCRC", "classc_c_r_c.html#a13a2654a59d3155f38e8a3fa23ef7de3", null ],
    [ "~cCRC", "classc_c_r_c.html#a76d34434ebc156dfe662aaffa2b1b688", null ],
    [ "operator()", "classc_c_r_c.html#a5a9690926776c095a1137389da00ddf5", null ]
];
var classc_hw_u_a_r_t___i_pclient =
[
    [ "Mode", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7a", [
      [ "BR_2400", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa7e36837fb51d5c4e2a2348adca5823fe", null ],
      [ "BR_4800", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa30b877e1ddae6cab5129401e42ae63d9", null ],
      [ "BR_9600", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa097e1d98212700334891916a035d58a1", null ],
      [ "BR_19200", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa9c60d346acf2304c637dc385833abae4", null ],
      [ "BR_38400", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa904a4b2dad091992506467e832fc9bb6", null ],
      [ "BR_57600", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa1d1449c8334943cd9812218fe6f8fa57", null ],
      [ "BR_115200", "classc_hw_u_a_r_t___i_pclient.html#a6e02deabeeec4c1d326a499d91585d7aa23afe2f9a5019603dd0a3b719a697118", null ]
    ] ],
    [ "cHwUART_IPclient", "classc_hw_u_a_r_t___i_pclient.html#a143a977994c49ce75de36a179f5f9114", null ],
    [ "getNext", "classc_hw_u_a_r_t___i_pclient.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_hw_u_a_r_t___i_pclient.html#ab07463368796c2655c2ce536159ab69e", null ],
    [ "set", "classc_hw_u_a_r_t___i_pclient.html#a83c62bd60080a8ad81e282067668a368", null ],
    [ "set", "classc_hw_u_a_r_t___i_pclient.html#a352418b6372e876c4abb41eb5e0b09c4", null ],
    [ "set", "classc_hw_u_a_r_t___i_pclient.html#af42cac9495a65380024bd26a78f637e6", null ],
    [ "isTxBufferFull", "classc_hw_u_a_r_t___i_pclient.html#a9539b9885188621b5716172c3219dd2c", null ],
    [ "get", "classc_hw_u_a_r_t___i_pclient.html#a80246ec9a1251a2176d5559b6a32c895", null ]
];
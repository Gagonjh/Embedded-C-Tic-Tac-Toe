var classc_download =
[
    [ "Interface", "classc_download_1_1_interface.html", "classc_download_1_1_interface" ],
    [ "cDownload", "classc_download.html#a176a610d577490460437c7d5bb8d5881", null ]
];
var classc_hw_d_a_c =
[
    [ "set", "classc_hw_d_a_c.html#a58c17c54dc888f5d7228438608b101b0", null ],
    [ "enable", "classc_hw_d_a_c.html#ae8f5e6ad548eeaf3e7f16d405b87d00a", null ],
    [ "getNumberOfChannels", "classc_hw_d_a_c.html#aec0028ce52139ceb58ad6f8c071f6e2d", null ]
];
var classc_data_pointer =
[
    [ "cDataPointer", "classc_data_pointer.html#a0c63f847b039c6a54e168a6bb94ba53e", null ],
    [ "cDataPointer", "classc_data_pointer.html#a5794ca1cbb766fe16ba22e9fd5c73007", null ],
    [ "cDataPointer", "classc_data_pointer.html#aef0e4c440427848ab35b95e14b5b1d4d", null ],
    [ "operator=", "classc_data_pointer.html#ae6d28f00d46160576275ca06540b9ae6", null ],
    [ "set", "classc_data_pointer.html#a20456cd9c717eb80c384178c6c3810bb", null ],
    [ "set", "classc_data_pointer.html#a0c87d9780d76a6e26fe938a587930c21", null ],
    [ "getPtr", "classc_data_pointer.html#a3ce40dc5e68b8da008021d5a57d4805c", null ],
    [ "operator T *", "classc_data_pointer.html#a245e85b7db1bff696e1ec9d7eae2fcd0", null ],
    [ "isEmpty", "classc_data_pointer.html#aed1bcea70707612a2abd8a4be87699a6", null ],
    [ "getSize", "classc_data_pointer.html#a6390864bff54ac6db04c4f1639d3f40f", null ],
    [ "shift", "classc_data_pointer.html#a911231b7e392ec0e2d9db99b526e2712", null ]
];
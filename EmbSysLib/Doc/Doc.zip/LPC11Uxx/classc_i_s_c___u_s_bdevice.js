var classc_i_s_c___u_s_bdevice =
[
    [ "cISC_USBdevice", "classc_i_s_c___u_s_bdevice.html#a0238e40a4d94924dba983e09aef738b6", null ],
    [ "update", "classc_i_s_c___u_s_bdevice.html#a3cc2b43728e673d0d16ecb4416e31a0e", null ]
];
var classc_hw_u_s_binterf_class_h_i_d =
[
    [ "requestCtrlIN", "classc_hw_u_s_binterf_class_h_i_d.html#a3405f39e9e3474a049c903425861b475", null ],
    [ "requestCtrlOUT", "classc_hw_u_s_binterf_class_h_i_d.html#a3ad46b3684dbd5a2a15487b1e07d646b", null ],
    [ "transmit", "classc_hw_u_s_binterf_class_h_i_d.html#a148d58cf182758b336e7df21751f9f72", null ],
    [ "request", "classc_hw_u_s_binterf_class_h_i_d.html#a55c4a9122aff962ca07014d6bf02a638", null ],
    [ "receive", "classc_hw_u_s_binterf_class_h_i_d.html#ac29c5e9ef208e698553b65ca24fb06a8", null ]
];
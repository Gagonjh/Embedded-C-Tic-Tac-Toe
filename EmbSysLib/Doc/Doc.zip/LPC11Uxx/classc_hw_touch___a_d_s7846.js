var classc_hw_touch___a_d_s7846 =
[
    [ "cHwTouch_ADS7846", "classc_hw_touch___a_d_s7846.html#a6079b0c5df08e5188687c7a9f64b2f6e", null ],
    [ "update", "classc_hw_touch___a_d_s7846.html#a54ad54381e7a10e2fe595800ac39e9c9", null ],
    [ "getPosX", "classc_hw_touch___a_d_s7846.html#a1e327d3cd157051c1bbf16b8a7740f59", null ],
    [ "getPosY", "classc_hw_touch___a_d_s7846.html#a52d2117d04e8e8e6b4f9d1a4bd0bb85c", null ],
    [ "isTouched", "classc_hw_touch___a_d_s7846.html#a0f853092414a61cea108cdc331cec73d", null ]
];
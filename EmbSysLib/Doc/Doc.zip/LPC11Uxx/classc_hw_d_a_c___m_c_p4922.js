var classc_hw_d_a_c___m_c_p4922 =
[
    [ "cHwDAC_MCP4922", "classc_hw_d_a_c___m_c_p4922.html#a2ab33161c06fc4928807e51075f0fd6a", null ],
    [ "set", "classc_hw_d_a_c___m_c_p4922.html#aafcb5958e252e2d504afe3f4fa0785e8", null ],
    [ "enable", "classc_hw_d_a_c___m_c_p4922.html#a71db1feed0b26fb818450abde38bca07", null ],
    [ "getNumberOfChannels", "classc_hw_d_a_c___m_c_p4922.html#aec0028ce52139ceb58ad6f8c071f6e2d", null ]
];
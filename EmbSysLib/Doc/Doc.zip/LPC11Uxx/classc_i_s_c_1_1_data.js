var classc_i_s_c_1_1_data =
[
    [ "Data", "classc_i_s_c_1_1_data.html#af1e3dc748836b8706587d777afd01c0e", null ],
    [ "write", "classc_i_s_c_1_1_data.html#aee1bf5077d0f36ecfe2f33abd448dfd2", null ],
    [ "isNew", "classc_i_s_c_1_1_data.html#a5b2489d4ddfccfb8f813b0701901044f", null ],
    [ "update", "classc_i_s_c_1_1_data.html#a1dff01e28a2707cfb30470934722042f", null ]
];
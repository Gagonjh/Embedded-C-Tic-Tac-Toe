var classc_hw_encoder___emul =
[
    [ "Mode", "classc_hw_encoder___emul.html#ad40cdad2041abe36f7b839d7e0edab44", [
      [ "NORMAL", "classc_hw_encoder___emul.html#ad40cdad2041abe36f7b839d7e0edab44af78831887bffc77e2abf355ae0b48200", null ],
      [ "REVERSE", "classc_hw_encoder___emul.html#ad40cdad2041abe36f7b839d7e0edab44a24a46cf2bd98f00ca693d4581d637f06", null ]
    ] ],
    [ "update", "classc_hw_encoder___emul.html#ae205df98ba3b5fb8710f4708b67160f1", null ],
    [ "get", "classc_hw_encoder___emul.html#ac54fa825a6340443eb7566bfb8ad9c8b", null ]
];
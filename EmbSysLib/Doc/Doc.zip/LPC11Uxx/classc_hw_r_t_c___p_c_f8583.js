var classc_hw_r_t_c___p_c_f8583 =
[
    [ "cHwRTC_PCF8583", "classc_hw_r_t_c___p_c_f8583.html#abb29205193115c3df2f2427adb4d3804", null ],
    [ "set", "classc_hw_r_t_c___p_c_f8583.html#a2fafe34f036fa57d7a99373f3f328cbd", null ],
    [ "get", "classc_hw_r_t_c___p_c_f8583.html#a5376850b625673a2669e13b4a64baa89", null ]
];
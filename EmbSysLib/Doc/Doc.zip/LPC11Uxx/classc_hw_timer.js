var classc_hw_timer =
[
    [ "Mode", "classc_hw_timer.html#a5c378ead2f2f3f9f26b34b265054f3f0", [
      [ "NORMAL", "classc_hw_timer.html#a5c378ead2f2f3f9f26b34b265054f3f0a71f1ae8a2d69af78acb16d6ed2c82be8", null ],
      [ "INVERS", "classc_hw_timer.html#a5c378ead2f2f3f9f26b34b265054f3f0a9395e4c132e8963e5d03f8146ff5d637", null ]
    ] ],
    [ "getCycleTime", "classc_hw_timer.html#a59140e7c3f5f07d49efccca8dedd9439", null ],
    [ "add", "classc_hw_timer.html#a1f92b385ea3f8e2ae431c58e29615181", null ],
    [ "enablePWM", "classc_hw_timer.html#a5e20950ac5603f4c39d7336896cc826f", null ],
    [ "setPWM", "classc_hw_timer.html#ace03950a46e90965dd7025bb181b375a", null ]
];
var classc_hw_u_s_bdesc =
[
    [ "cConfiguration", "classc_hw_u_s_bdesc_1_1c_configuration.html", null ],
    [ "cDevice", "classc_hw_u_s_bdesc_1_1c_device.html", null ],
    [ "cEndpoint", "classc_hw_u_s_bdesc_1_1c_endpoint.html", null ],
    [ "cHID", "classc_hw_u_s_bdesc_1_1c_h_i_d.html", "classc_hw_u_s_bdesc_1_1c_h_i_d" ],
    [ "cInterface", "classc_hw_u_s_bdesc_1_1c_interface.html", null ],
    [ "cReport", "classc_hw_u_s_bdesc_1_1c_report.html", null ],
    [ "cString", "classc_hw_u_s_bdesc_1_1c_string.html", null ],
    [ "DeviceClassType", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770af", [
      [ "RESERVED_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa67ac28e94951fa515acd27e5f6344b2c", null ],
      [ "AUDIO_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa128a221137ff6f515976ba8842cd296b", null ],
      [ "COMMUNICATIONS_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afaacc5fa42136f225bd7b34b71100056c0", null ],
      [ "HUMAN_INTERFACE_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa288496c44b7deba82e436bb9fcd288e6", null ],
      [ "MONITOR_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa1bb1d774043f57e2cfc45044ccfc24fc", null ],
      [ "PHYSICAL_INTERFACE_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afadbd1a65d9ed417edfb738e8faf820424", null ],
      [ "POWER_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa33c3c6770f2b39019ded9c4fdfeccb61", null ],
      [ "PRINTER_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa5b536adb4fc5ec3c8ddb08020b042132", null ],
      [ "STORAGE_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa35ad58f253f02b2ce7598b1d4c3e5347", null ],
      [ "HUB_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa8df23b4c7065ffe8846c59e706b2b41e", null ],
      [ "MISCELLANEOUS_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afa63dae7f5ec1b42eeb5a79fd53af8dbe1", null ],
      [ "VENDOR_SPECIFIC_CLASS", "classc_hw_u_s_bdesc.html#a623c249cda4d9d0409a71c7956f770afafc38fdeb32b750d537a23140a11c649f", null ]
    ] ],
    [ "EndpointType", "classc_hw_u_s_bdesc.html#a346f6a703b68b5690cf27df0d8fe9f24", null ]
];
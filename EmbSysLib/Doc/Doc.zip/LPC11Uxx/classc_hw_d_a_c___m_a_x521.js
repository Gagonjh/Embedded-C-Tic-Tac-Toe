var classc_hw_d_a_c___m_a_x521 =
[
    [ "cHwDAC_MAX521", "classc_hw_d_a_c___m_a_x521.html#ad4f4f9c6126627a884ea335bfe29b417", null ],
    [ "set", "classc_hw_d_a_c___m_a_x521.html#a6fd12006f5bb12270aec31e242cab8a8", null ],
    [ "enable", "classc_hw_d_a_c___m_a_x521.html#a152294ba6feefd26472909e33ace6eed", null ],
    [ "getNumberOfChannels", "classc_hw_d_a_c___m_a_x521.html#aec0028ce52139ceb58ad6f8c071f6e2d", null ]
];
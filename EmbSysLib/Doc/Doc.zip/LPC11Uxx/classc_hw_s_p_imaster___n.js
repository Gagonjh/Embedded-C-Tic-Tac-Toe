var classc_hw_s_p_imaster___n =
[
    [ "MODE", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92e", [
      [ "CR_250kHz", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92ea4700e2bceff03759b7932d327b84ed83", null ],
      [ "CR_500kHz", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92ea52f2d50b84136bcc91de0ddb28dec768", null ],
      [ "CR_1000kHz", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92eaf4038d567853729b8cfd8ff447bdc913", null ],
      [ "CR_2000kHz", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92ea106d3633c79980d3e2cb29caea563439", null ],
      [ "CR_4000kHz", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92ea29f0738976d2ef14040062d113059097", null ],
      [ "CR_8000kHz", "classc_hw_s_p_imaster___n.html#a934e17532d385f4aa68c381563b7c92ea502a61656d043a8c3f8b84c88c080354", null ]
    ] ],
    [ "ClockPolPha", "classc_hw_s_p_imaster___n.html#aeac7c840ba3474230a69b30e657d5edf", [
      [ "CPOL_L_CPHA_L", "classc_hw_s_p_imaster___n.html#aeac7c840ba3474230a69b30e657d5edfabde47704c2fdeb24e0f746c690a10974", null ],
      [ "CPOL_L_CPHA_H", "classc_hw_s_p_imaster___n.html#aeac7c840ba3474230a69b30e657d5edfa77db6c8f7b98cb4afed3e47550849502", null ],
      [ "CPOL_H_CPHA_L", "classc_hw_s_p_imaster___n.html#aeac7c840ba3474230a69b30e657d5edfa871aa10d9ada3bdd8252adc43bbd5ad2", null ],
      [ "CPOL_H_CPHA_H", "classc_hw_s_p_imaster___n.html#aeac7c840ba3474230a69b30e657d5edfa288da4dadb38601f13cfef74c31077a7", null ]
    ] ],
    [ "cHwSPImaster_N", "classc_hw_s_p_imaster___n.html#aa23ade10e33aa3b530a21017b1dbe69e", null ],
    [ "transceiveByte", "classc_hw_s_p_imaster___n.html#aba80c1453f96fa9cf4175a480ec7e62b", null ]
];
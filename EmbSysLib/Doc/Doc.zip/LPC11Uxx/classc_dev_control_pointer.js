var classc_dev_control_pointer =
[
    [ "cData", "classc_dev_control_pointer_1_1c_data.html", "classc_dev_control_pointer_1_1c_data" ],
    [ "cDevControlPointer", "classc_dev_control_pointer.html#a190eaefb85e0eeb30952649093f898dd", null ],
    [ "get", "classc_dev_control_pointer.html#a9142b4c89c80756cad42d3ef7d1579f4", null ]
];
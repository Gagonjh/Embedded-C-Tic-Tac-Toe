var classc_dev_display_graphic =
[
    [ "cDevDisplayGraphic", "classc_dev_display_graphic.html#aa024e3d1a8d314537b8f19a615d4d7f3", null ],
    [ "clear", "classc_dev_display_graphic.html#a3240103993533749746722476130c29a", null ],
    [ "refresh", "classc_dev_display_graphic.html#a27c382e28b9838e8904e810baa99e5f1", null ],
    [ "printf", "classc_dev_display_graphic.html#a2cf9903de84c2924672566d53c62248a", null ],
    [ "setFont", "classc_dev_display_graphic.html#a4ada02d3384a7cffbd5b3e846d71d8ec", null ],
    [ "setZoom", "classc_dev_display_graphic.html#a8a44ff17d4c1ad47e81a5c21c3acf1ae", null ],
    [ "setBackColor", "classc_dev_display_graphic.html#ad7ae4bcd3874f28fcca75bb3c080e092", null ],
    [ "setTextColor", "classc_dev_display_graphic.html#a384ab0b42bcd3310d786dc600e191090", null ],
    [ "drawText", "classc_dev_display_graphic.html#a11ae4b997dff065c67346589eb5bdbcb", null ],
    [ "drawText", "classc_dev_display_graphic.html#a873eef90be4eac9f30cfd92449ff52e0", null ],
    [ "drawPixel", "classc_dev_display_graphic.html#a1343a6d4e6d5d8df9d3c504370cd2c75", null ],
    [ "drawRectangle", "classc_dev_display_graphic.html#a53b343b8aaf2fcb66c8c1d67fb5a8218", null ],
    [ "drawFrame", "classc_dev_display_graphic.html#a62f1f5c8071bee4bba91ac8be6ae8543", null ],
    [ "drawCircle", "classc_dev_display_graphic.html#a1b0920112dd4a9594c32a29024e1f597", null ],
    [ "drawLine", "classc_dev_display_graphic.html#a6d18ecd05b6f7c63a773a787865e9bcf", null ],
    [ "drawBitmap", "classc_dev_display_graphic.html#a028205166d5424b474233ec49c655d83", null ],
    [ "getDefaultFont", "classc_dev_display_graphic.html#aed285a7b040e01e6673a29b429d3aed7", null ]
];
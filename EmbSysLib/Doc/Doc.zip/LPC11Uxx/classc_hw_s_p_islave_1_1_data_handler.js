var classc_hw_s_p_islave_1_1_data_handler =
[
    [ "transceive", "classc_hw_s_p_islave_1_1_data_handler.html#a1f0b7c40ccd146a3d8a452b7e1af7854", null ]
];
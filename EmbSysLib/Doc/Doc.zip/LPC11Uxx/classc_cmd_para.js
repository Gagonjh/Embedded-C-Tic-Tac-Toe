var classc_cmd_para =
[
    [ "modeType", "classc_cmd_para.html#a9ce830464e14fecd6a7a0db6f2eaafa6", [
      [ "NORMAL", "classc_cmd_para.html#a9ce830464e14fecd6a7a0db6f2eaafa6a539c6c9fc9f7ed86c6d5b87b82a3745e", null ],
      [ "RDONLY", "classc_cmd_para.html#a9ce830464e14fecd6a7a0db6f2eaafa6acaabf6dcc2092a84c6f32a7e36aca9e8", null ],
      [ "MEMORY", "classc_cmd_para.html#a9ce830464e14fecd6a7a0db6f2eaafa6a12b77fea5755b18bb44af5c8b009bce3", null ],
      [ "EVENT", "classc_cmd_para.html#a9ce830464e14fecd6a7a0db6f2eaafa6ab870e4c688e44c9ea666f94a2647d340", null ]
    ] ],
    [ "isNew", "classc_cmd_para.html#a95ad4cd84a91028d63579ed394b6cd14", null ]
];
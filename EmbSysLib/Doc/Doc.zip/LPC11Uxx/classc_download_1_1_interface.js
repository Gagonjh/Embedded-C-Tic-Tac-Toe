var classc_download_1_1_interface =
[
    [ "Interface", "classc_download_1_1_interface.html#a4928e2c6bb76bfb5075f8b3163b09bdd", null ],
    [ "onStart", "classc_download_1_1_interface.html#a93886483f4ecc9634dd4cf0e26207f06", null ],
    [ "onReady", "classc_download_1_1_interface.html#a584c0b695702363a993145ba0430170c", null ],
    [ "isNew", "classc_download_1_1_interface.html#a999f50f61e5e213c153354bca2915c96", null ],
    [ "isRunning", "classc_download_1_1_interface.html#a8b96c0f9ccecde522350a012255fb322", null ],
    [ "getSize", "classc_download_1_1_interface.html#a562924b6bace0fdd11efbf76cc8c3ccc", null ],
    [ "getNext", "classc_download_1_1_interface.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_download_1_1_interface.html#ab07463368796c2655c2ce536159ab69e", null ],
    [ "mem", "classc_download_1_1_interface.html#ab389cf91c22c3a97e282bba2b2f79c05", null ]
];
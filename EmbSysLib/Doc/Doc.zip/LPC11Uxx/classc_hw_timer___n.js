var classc_hw_timer___n =
[
    [ "TIM_ID", "classc_hw_timer___n.html#a241a758ffe3363239a43a5ee6babb76a", [
      [ "CT16B0", "classc_hw_timer___n.html#a241a758ffe3363239a43a5ee6babb76aa2b1cb262ccb47899e61dc6cbc019fea7", null ],
      [ "CT16B1", "classc_hw_timer___n.html#a241a758ffe3363239a43a5ee6babb76aaa50d38eb121e9d5f29989dfd034bc543", null ],
      [ "CT32B0", "classc_hw_timer___n.html#a241a758ffe3363239a43a5ee6babb76aa0c4f6f53ed25761cfffaeea6265bcb32", null ],
      [ "CT32B1", "classc_hw_timer___n.html#a241a758ffe3363239a43a5ee6babb76aaa810c02c08fc727ca8bf51e7c26d2f28", null ]
    ] ],
    [ "Mode", "classc_hw_timer___n.html#a5c378ead2f2f3f9f26b34b265054f3f0", [
      [ "NORMAL", "classc_hw_timer___n.html#a5c378ead2f2f3f9f26b34b265054f3f0a71f1ae8a2d69af78acb16d6ed2c82be8", null ],
      [ "INVERS", "classc_hw_timer___n.html#a5c378ead2f2f3f9f26b34b265054f3f0a9395e4c132e8963e5d03f8146ff5d637", null ]
    ] ],
    [ "cHwTimer_N", "classc_hw_timer___n.html#a4c7fa77784e2c72102386e8d92574542", null ],
    [ "enablePWM", "classc_hw_timer___n.html#a8a164536707167ac68d9fbf25c3cc1c0", null ],
    [ "setPWM", "classc_hw_timer___n.html#a5cb42233ebc8a8b58ba741ed652c37c8", null ],
    [ "getCycleTime", "classc_hw_timer___n.html#a59140e7c3f5f07d49efccca8dedd9439", null ],
    [ "add", "classc_hw_timer___n.html#a1f92b385ea3f8e2ae431c58e29615181", null ]
];
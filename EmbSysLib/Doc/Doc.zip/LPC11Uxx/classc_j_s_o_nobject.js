var classc_j_s_o_nobject =
[
    [ "getNext", "classc_j_s_o_nobject.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_j_s_o_nobject.html#ab07463368796c2655c2ce536159ab69e", null ]
];
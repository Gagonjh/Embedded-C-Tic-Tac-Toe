var classc_hw_display_font_properties =
[
    [ "firstId", "classc_hw_display_font_properties.html#a429b104fbf64c10eefebb5a84c8003b2", null ],
    [ "lastId", "classc_hw_display_font_properties.html#a6580a1511a57aac3296732702d777fa9", null ],
    [ "bytePerChar", "classc_hw_display_font_properties.html#a3966a20ff5299fe8d4e4433dace326dd", null ],
    [ "charWidth", "classc_hw_display_font_properties.html#adc69eabd3ab15e716e74b8112d22c3ec", null ],
    [ "charHeight", "classc_hw_display_font_properties.html#a35206a069389e31922c526d06b4e9b8e", null ]
];
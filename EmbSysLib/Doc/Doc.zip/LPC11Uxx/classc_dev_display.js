var classc_dev_display =
[
    [ "clear", "classc_dev_display.html#a95c2a7291cd131e3f595efd0dce681c0", null ],
    [ "refresh", "classc_dev_display.html#a96e36692f71c3e4f71e1f8c0f8eef984", null ],
    [ "printf", "classc_dev_display.html#a338e7318eab8aa98fe21a15d56c06cca", null ]
];
var classc_data_storage_1_1_record_handler =
[
    [ "update", "classc_data_storage_1_1_record_handler.html#a506efb19d50a0876e664689d3b371fb6", null ],
    [ "getNext", "classc_data_storage_1_1_record_handler.html#a2acbaba5b0b74a0a79a3a39b55e61eb0", null ],
    [ "getPrev", "classc_data_storage_1_1_record_handler.html#ab07463368796c2655c2ce536159ab69e", null ]
];
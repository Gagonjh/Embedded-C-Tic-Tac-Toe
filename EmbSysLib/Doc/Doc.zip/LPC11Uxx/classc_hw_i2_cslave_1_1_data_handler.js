var classc_hw_i2_cslave_1_1_data_handler =
[
    [ "receive", "classc_hw_i2_cslave_1_1_data_handler.html#a484e7d4326e676ec3e117df53e6c6330", null ],
    [ "transmit", "classc_hw_i2_cslave_1_1_data_handler.html#a17a18b2146f12e2f61431d078bd9c2c6", null ]
];
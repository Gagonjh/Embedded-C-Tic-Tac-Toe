var classc_hw_touch___s_t_m_p_e811i2c =
[
    [ "cHwTouch_STMPE811i2c", "classc_hw_touch___s_t_m_p_e811i2c.html#ab57e48083c2c3bc719510c64b26114ca", null ],
    [ "update", "classc_hw_touch___s_t_m_p_e811i2c.html#abc2860355f0f62421eb72498fe50a292", null ],
    [ "getPosX", "classc_hw_touch___s_t_m_p_e811i2c.html#a1e327d3cd157051c1bbf16b8a7740f59", null ],
    [ "getPosY", "classc_hw_touch___s_t_m_p_e811i2c.html#a52d2117d04e8e8e6b4f9d1a4bd0bb85c", null ],
    [ "isTouched", "classc_hw_touch___s_t_m_p_e811i2c.html#a0f853092414a61cea108cdc331cec73d", null ]
];